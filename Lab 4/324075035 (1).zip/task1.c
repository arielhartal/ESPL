#include <stdlib.h>
#include <stdio.h>
#include <string.h>
typedef struct {
 char debug_mode;
 char display_mode;
 char file_name[128];
 int unit_size;
 unsigned char mem_buf[10000];
 size_t mem_count;
 /*
 .
 .
 Any addritional fields you deem necessary
 */
} state;

struct fun_desc{
    char* name;
    void (*fun)(state*);
};

void toggle_debug_mode(state* s){
    if(s->debug_mode)
    {
        s->debug_mode = 0;
        fprintf(stderr, "Debug flag off\n");
    } 
    else
    {
        s->debug_mode = 1;
        fprintf(stderr, "Debug flag on\n");
    }
}

void set_file_name(state* s){
    printf("Please enter file name:\n");
    fgets(s->file_name, 100, stdin);
    s->file_name[strlen(s->file_name) - 1] = '\0';  
    if(s->debug_mode){
        fprintf(stderr, "Debug: file name set to '%s'\n", s->file_name);
    }
}

void set_unit_size(state* s){
    printf("Please enter unit size:\n");
    char buffer[100];
    fgets(buffer, 100, stdin);
    int unit_size_entered;
    sscanf(buffer, "%d\n", &unit_size_entered);
    if(unit_size_entered == 1 || unit_size_entered == 2 || unit_size_entered == 4)
    {
        s->unit_size = unit_size_entered;
        if(s->debug_mode)
            fprintf(stderr, "Debug: set size to %d\n", unit_size_entered);
    }
    else
    {
        fprintf(stderr, "Invalid unit size\n");
    }
}

void load_into_memory(state* s){
    if(strcmp(s->file_name, "") == 0)
    {
        fprintf(stderr, "no file name was given\n");
        return;
    }
    FILE* f = fopen(s->file_name, "r");
    if(f == NULL){
        fprintf(stderr, "error opening file %s\n", s->file_name);
        return;
    }

    printf("Please enter location length:\n");
    char buffer[100];
    fgets(buffer, 100, stdin);
    int location;
    int length;
    sscanf(buffer, "%x %d\n", &location, &length);
    
    if(s->debug_mode)
    {
        fprintf(stderr, "File name: %s\nLocation: %x\n length: %d\n", s->file_name, location, length);
    }

    fseek(f, location, SEEK_SET);
    int nread = fread(s->mem_buf, s->unit_size, length, f);
    printf("Loaded %d units\n", nread);
    fclose(f);
}

void toggle_display_mode(state* s){
    if(s->display_mode)
    {
        s->display_mode = 0;
        fprintf(stderr, "Display flag now off, decimal representation\n");
    } 
    else
    {
        s->display_mode = 1;
        fprintf(stderr, "Display flag now on, hexadecimal representation\n");
    }
}

void memory_display(state* s){
    static char* hex_formats[] = {"%#hhx\n", "%#hx\n", "No such unit", "%#x\n"};
    static char* dec_formats[] = {"%#hhd\n", "%#hd\n", "No such unit", "%#d\n"};
    printf("Enter addrress and length:\n");
    char buffer[100];
    fgets(buffer, 100, stdin);
    int address;
    int length;
    sscanf(buffer, "%x %d\n", &address, &length);
    unsigned char* addr = (unsigned char*) address;
    if(address == 0){
        addr = s->mem_buf;
    }
    if(s->display_mode){
        printf("Hexadecimal\n");
        printf("===========\n");   
    } else {
        printf("Decimal\n");
        printf("=======\n");
    }
    for(int i = 0; i < length; i++)
    {
        int value = *((int*)(addr + i * s->unit_size));
        if(s->display_mode){
            printf(hex_formats[s->unit_size-1], value);
        } else {
            printf(dec_formats[s->unit_size-1], value);
        }   
    }
}

void save_into_file(state* s){
    if(strcmp(s->file_name, "") == 0){
        fprintf(stderr, "no file name was given\n");
        return;
    }
    FILE* f = fopen(s->file_name, "r+");
    if(f == NULL)
    {
        fprintf(stderr, "error opening file %s\n", s->file_name);
        return;
    }

    printf("Please enter source target length:\n");
    char buffer[100];
    fgets(buffer, 100, stdin);
    int source;
    int target;
    int length;
    sscanf(buffer, "%x %x %d\n", &source, &target, &length);
    
    unsigned char* addr = (unsigned char*) source;
    if(source == 0)
    {
        addr = s->mem_buf;
    }
    
    fseek(f, target, SEEK_END);
    if(ftell(f) >= target){
        fseek(f, target, SEEK_SET);
        int nread = fwrite(addr, s->unit_size, length, f);
        printf("Loaded %d units\n", nread);
    } 
    else {
        printf("Target is bigger than file size\n");
    }
    fclose(f);
}

void memory_modify(state* s){
    printf("Please enter location value:\n");
    char buffer[100];
    fgets(buffer, 100, stdin);
    int location;
    int value;
    sscanf(buffer, "%x %x\n", &location, &value);
    strncpy((char*)s->mem_buf + location*s->unit_size, (char*)(&value), s->unit_size);
}

void quit(state* s){
    free(s);
    fprintf(stderr, "quiting...\n");
    exit(0);
}


int main(int argc, char** argv){
    state* s = malloc(sizeof(state));
    s->debug_mode = 0;
    s->unit_size = 1;
    strcpy(s->file_name, "");
    struct fun_desc menu[] = {
        {"Toggle Debug Mode", toggle_debug_mode},
        {"Set File Name", set_file_name},
        {"Set Unit Size", set_unit_size},
        {"Load Into Memory", load_into_memory},
        {"Toggle Display Mode", toggle_display_mode},
        {"Memory Display", memory_display},
        {"Save Into File", save_into_file},
        {"Memory Modify", memory_modify},
        {"Quit ", quit}, 
        { NULL, NULL } };
    int size_of_menu = sizeof(menu) / sizeof(struct fun_desc) - 1;
    char input[100];
    while(1){
        printf("Select operation from the following menu:\n");
        for(int i = 0; i < size_of_menu; i++){
            printf("%d-%s\n", i, menu[i].name);
        }
        printf("option: ");
        if(fgets(input, 100, stdin) == NULL){
            break;
        }
        int option;
        sscanf(input, "%d\n", &option);
        if(option < 0 || option >= size_of_menu){
            printf("Not within bounds\n");
            break;
        }
        printf("Within bounds\n");
        menu[option].fun(s);
        printf("DONE.\n\n");
    } 
}