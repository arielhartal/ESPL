#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

#define MESSAGE "hello"

int main() {
    int fd[2];
    pid_t pid;

    if (pipe(fd) < 0) {
        perror("pipe");
        exit(EXIT_FAILURE);
    }

    pid = fork();

    if (pid < 0) {
        perror("fork");
        exit(EXIT_FAILURE);
    }

    if (pid == 0) {
        // Child process writes MESSAGE to pipe
        close(fd[0]); // Close read end
        write(fd[1], MESSAGE, strlen(MESSAGE) + 1);
        close(fd[1]); // Close write end
        exit(EXIT_SUCCESS);
    } else {
        // Parent process reads MESSAGE from pipe
        char buf[strlen(MESSAGE) + 1];
        close(fd[1]); // Close write end
        read(fd[0], buf, strlen(MESSAGE) + 1);
        printf("%s\n", buf);
        close(fd[0]); // Close read end
        exit(EXIT_SUCCESS);
    }

    return 0;
}
