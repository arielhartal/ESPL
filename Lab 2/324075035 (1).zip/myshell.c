#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits.h>
#include <string.h>
#include <sys/wait.h>
#include "LineParser.h"
#include <errno.h>
#include <fcntl.h>

#define BUFFER_SIZE 2048



void displayPrompt() {
    char cwd[PATH_MAX];
    if (getcwd(cwd, PATH_MAX) != NULL) {
        printf("%s$ ", cwd);
    }
    else {
        perror("Error getting current working directory");
    }
}


void suspendCmd(char* pidStr) {
    pid_t pid = atoi(pidStr);
    int res = kill(pid, SIGTSTP);
    if (res != 0) {
        perror("kill failed");
    }
}

void wakeCmd(char* pidStr) {
    pid_t pid = atoi(pidStr);
    int res = kill(pid, SIGCONT);
    if (res != 0) {
        perror("kill failed");
    }
}


void killCmd(char* pidStr) {
    pid_t pid = atoi(pidStr);
    int res = kill(pid, SIGINT);
  //  int status;
  //  waitpid(pid, &status, 0);
    if (res != 0) {
        perror("kill failed");
    }
}


void execute(cmdLine *pCmdLine) {
    if (strcmp(pCmdLine->arguments[0], "cd") == 0) {
        if (chdir(pCmdLine->arguments[1]) != 0) {
            fprintf(stderr, "Error changing directory: %s\n", strerror(errno));
        }
    }

    else if (strcmp(pCmdLine->arguments[0], "suspend") == 0) {
        char* pid = pCmdLine->arguments[1];
        suspendCmd(pid);
    }
    else if (strcmp(pCmdLine->arguments[0], "wake") == 0) {
        char* pid = pCmdLine->arguments[1];
        wakeCmd(pid);
    }
    else if (strcmp(pCmdLine->arguments[0], "kill") == 0) {
        char* pid = pCmdLine->arguments[1];
        killCmd(pid);
    }

    else {
        pid_t pid = fork();

        if (pid == -1) {
            perror("Error forking");
            exit(EXIT_FAILURE);
        }
        else if (pid == 0) {
            // Child process
            if (pCmdLine->inputRedirect != NULL) {
                int fd = open(pCmdLine->inputRedirect, O_RDONLY);
                if (fd == -1) {
                    perror("Error opening input file");
                    exit(EXIT_FAILURE);
                }
                if (dup2(fd, STDIN_FILENO) == -1) {
                    perror("Error redirecting input");
                    exit(EXIT_FAILURE);
                }
                close(fd);
            }
            if (pCmdLine->outputRedirect != NULL) {
                int fd = open(pCmdLine->outputRedirect, O_WRONLY | O_CREAT | O_TRUNC, 0666);
                if (fd == -1) {
                    perror("Error opening output file");
                    exit(EXIT_FAILURE);
                }
                if (dup2(fd, STDOUT_FILENO) == -1) {
                    perror("Error redirecting output");
                    exit(EXIT_FAILURE);
                }
                close(fd);
            }
            if (execvp(pCmdLine->arguments[0], pCmdLine->arguments) == -1) {
                perror("Error executing command");
                _exit(EXIT_FAILURE);
            }
        }
        else {
            // Parent process
            if (pCmdLine->blocking) {
                int status;
                if (waitpid(pid, &status, 0) == -1) {
                    perror("Error waiting for child process");
                    exit(EXIT_FAILURE);
                }
            }
        }
    }
}


int main(int argc, char **argv) {
    char buffer[BUFFER_SIZE];
    cmdLine *cmd;
    int quit = 0;

    int debug_mode = -1;
    for(int i = 1; i < argc; i++)
    {
        if(argv[i][0] == '-' && argv[i][1] == 'd' && argv[i][2] == '\0')
        {
            debug_mode = 1;
        }


    }


    while (!quit) {
        displayPrompt();
        fgets(buffer, BUFFER_SIZE, stdin);
        cmd = parseCmdLines(buffer);

        if (strcmp(cmd->arguments[0], "quit") == 0) {
            quit = 1;
            freeCmdLines(cmd);
            exit(EXIT_SUCCESS);
        }
        else {
            int pid = fork();
            if (pid == -1) {
                perror("Error forking");
            }
            else if (pid == 0) {
                if(debug_mode == 1)
                {
                    fprintf(stderr, "PID: %d\n", getpid());
                    fprintf(stderr, "Command: %s\n", cmd->arguments[0]);
                }
                execute(cmd);
            }
            else {
                wait(NULL);
            }
        }

        freeCmdLines(cmd);
    }

    return 0;
}



