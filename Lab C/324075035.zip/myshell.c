#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <limits.h>
#include <string.h>
#include <sys/wait.h>
#include "LineParser.h"
#include <errno.h>
#include <fcntl.h>
#include <ctype.h>


#define BUFFER_SIZE 2048

typedef struct process {
    cmdLine *cmd;
    pid_t pid;
    int status;
    struct process *next;
} process;

#define TERMINATED -1
#define RUNNING 1
#define SUSPENDED 0
#define HISTLEN 20

char *history[HISTLEN];
int newest = 0;
int oldest = 0;

void add_to_history(char *command) {
    if (history[oldest] != NULL) {
        free(history[oldest]);
    }
    history[oldest] = strdup(command);
    newest = oldest;
    oldest = (oldest + 1) % HISTLEN;
}

void print_history() {
    for (int i = 0; i < HISTLEN; i++) {
        if (history[i] != NULL) {
            printf("%d %s", i + 1, history[i]);
        }
    }
}






void addProcess(process **process_list, cmdLine *cmd, pid_t pid) {
    process *new_process = malloc(sizeof(process));
    new_process->cmd = cmd;
    new_process->pid = pid;
    new_process->status = RUNNING;
    new_process->next = *process_list;
    *process_list = new_process;
}

void freeProcessList(process* process_list) {
    process *current = process_list;
    process *next;

    while (current != NULL) {
        next = current->next;
        free(current->cmd);
        free(current);
        current = next;
    }
}

void updateProcessStatus(process* process_list, int pid, int status) {
    process *current = process_list;
    while (current != NULL) {
        if (current->pid == pid) {
            current->status = status;
            break;
        }
        current = current->next;
    }
}

void updateProcessList(process **process_list) {
    process *proc = *process_list;
    int status;
    int pid;

    while (proc != NULL) {
        pid = waitpid(proc->pid, &status, WNOHANG | WUNTRACED | WCONTINUED);
        if (pid > 0) {
            if (WIFEXITED(status) || WIFSIGNALED(status)) {
                updateProcessStatus(*process_list, proc->pid, TERMINATED);
            } else if (WIFSTOPPED(status)) {
                updateProcessStatus(*process_list, proc->pid, SUSPENDED);
            } else if (WIFCONTINUED(status)) {
                updateProcessStatus(*process_list, proc->pid, RUNNING);
            }
        }
        proc = proc->next;
    }
}



void printProcessList(process **process_list) {

    updateProcessList(process_list);
    
    if (*process_list != NULL) {
        printf("PID\tStatus\t\tCommand\n");
    }

    
    process *current = *process_list;
    process *prev = NULL;
    int index = 1;

    while (current != NULL) {
        if (current->pid == getpid()) {
            prev = current;
            current = current->next;
            continue;
        }

        printf("%d\t", current->pid);

        if (current->status == RUNNING) {
            printf("Running\t\t");
        } else if (current->status == SUSPENDED) {
            printf("Suspended\t");
        } else if (current->status == TERMINATED) {
            printf("Terminated\t");
        }

        for (int i = 0; i < current->cmd->argCount; i++) {
            printf("%s ", current->cmd->arguments[i]);
        }
        printf("\n");
        if (current->status == TERMINATED) {
            if (prev == NULL) {
                *process_list = current->next;
                current = *process_list;
            } else {
                prev->next = current->next;
                current = prev->next;
            }
            
            continue;
        }
        index++;
        prev = current;
        current = current->next;
    }


}



void displayPrompt() {
    char cwd[PATH_MAX];
    if (getcwd(cwd, PATH_MAX) != NULL) {
        printf("%s$ ", cwd);
    }
    else {
        perror("Error getting current working directory");
    }
}


void suspendCmd(char* pidStr, process **process_list) {
    pid_t pid = atoi(pidStr);
    int res = kill(pid, SIGTSTP);
    if (res != 0) {
        perror("kill failed");
    }
}

void killCmd(char* pidStr, process** process_list) {
    pid_t pid = atoi(pidStr);
    if(kill(pid, SIGINT) < 0)
        perror("kill failed");
}

void wakeCmd(char* pidStr, process** process_list) {
    pid_t pid = atoi(pidStr);
    int res = kill(pid, SIGCONT);
    if (res != 0) {
        perror("kill failed");
    }
}



void print_fd_flags(int fd) {
    int flags = fcntl(fd, F_GETFL);
    if (flags == -1) {
        perror("fcntl");
        return;
    }
    printf("File descriptor %d flags: ", fd);
    if (flags & O_RDONLY) printf("O_RDONLY ");
    if (flags & O_WRONLY) printf("O_WRONLY ");
    if (flags & O_RDWR) printf("O_RDWR ");
    printf("\n");
}


void execute_pipe(cmdLine *pCmdLine){
    int pipefd[2];
    if (pipe(pipefd) == -1) {
        perror("pipe");
        exit(EXIT_FAILURE);
    }
    pid_t pid = fork();
    
    if (pid == -1) {
        perror("Error forking");
        exit(EXIT_FAILURE);
    }
    else if (pid == 0) {
        if (pCmdLine->inputRedirect != NULL) {
            int fd = open(pCmdLine->inputRedirect, O_RDONLY);
            if (fd == -1) {
                perror("Error opening input file");
                exit(EXIT_FAILURE);
            }
            if (dup2(fd, STDIN_FILENO) == -1) {
                perror("Error redirecting input");
                exit(EXIT_FAILURE);
            }
            close(fd);
        }
        close(STDOUT_FILENO);
        dup(pipefd[1]);
        close(pipefd[1]);
        close(pipefd[0]);
        if (execvp(pCmdLine->arguments[0], pCmdLine->arguments) == -1) {
            perror("Error executing command");
            _exit(EXIT_FAILURE);
        }
    } else {
        if (pCmdLine->next->outputRedirect != NULL) {
            int fd = open(pCmdLine->next->outputRedirect, O_WRONLY | O_CREAT | O_TRUNC, 0666);
            if (fd == -1) {
                perror("Error opening output file");
                exit(EXIT_FAILURE);
            }
            if (dup2(fd, STDOUT_FILENO) == -1) {
                perror("Error redirecting output");
                exit(EXIT_FAILURE);
            }
            close(fd);
        }
        close(STDIN_FILENO);
        dup(pipefd[0]);
        close(pipefd[0]);
        close(pipefd[1]);
        waitpid(pid, NULL, 0);
        if (execvp(pCmdLine->next->arguments[0], pCmdLine->next->arguments) == -1) {
            perror("Error executing command");
            _exit(EXIT_FAILURE);
        }
    }
}





void execute(cmdLine *pCmdLine, process** process_list) {
    int is_pipeline = pCmdLine->next != NULL;

    if (is_pipeline) {
        if (pCmdLine->outputRedirect != NULL) {
            fprintf(stderr, "Error: Invalid output redirection for left-hand side process.\n");
            return;
        }

        if (pCmdLine->next->inputRedirect != NULL) {
            fprintf(stderr, "Error: Invalid input redirection for right-hand side process.\n");
            return;
        }
    }
    
    if (strcmp(pCmdLine->arguments[0], "cd") == 0) {
        if (chdir(pCmdLine->arguments[1]) != 0) {
            fprintf(stderr, "Error changing directory: %s\n", strerror(errno));
        }
    }
     else {
        int is_pipeline = pCmdLine->next != NULL;
        if(is_pipeline)
        {
            execute_pipe(pCmdLine);
        }
        else {

            if (pCmdLine->inputRedirect != NULL) {
                int fd = open(pCmdLine->inputRedirect, O_RDONLY);
                if (fd == -1) {
                    perror("Error opening input file");
                    exit(EXIT_FAILURE);
                }
                if (dup2(fd, STDIN_FILENO) == -1) {
                    perror("Error redirecting input");
                    exit(EXIT_FAILURE);
                }
                close(fd);

            
            }
            if (pCmdLine->outputRedirect != NULL) {
                int fd = open(pCmdLine->outputRedirect, O_WRONLY | O_CREAT | O_TRUNC, 0666);
                if (fd == -1) {
                    perror("Error opening output file");
                    exit(EXIT_FAILURE);
                }
                if (dup2(fd, STDOUT_FILENO) == -1) {
                    perror("Error redirecting output");
                    exit(EXIT_FAILURE);
                }
                close(fd);
            }
            if (execvp(pCmdLine->arguments[0], pCmdLine->arguments) == -1) {
                if(strcmp(pCmdLine->arguments[0], "history") != 0)
                {
                    perror("Error executing command");
                }
                _exit(EXIT_FAILURE);
            }
        }
    }
}


char* execute_last_command() {
    int last_command_index = newest;
    while (1) {
        if (history[last_command_index] != NULL &&
            strcmp(history[last_command_index], "history\n") != 0 &&
            strcmp(history[last_command_index], "!!\n") != 0 &&
            (history[last_command_index][0] != '!' || !isdigit(history[last_command_index][1]))) {
            add_to_history(history[last_command_index]);
            return history[last_command_index];
        }
        
        last_command_index = (last_command_index - 1 + HISTLEN) % HISTLEN;
        if (last_command_index == newest) {
            printf("Error: No previous non-history command found.\n");
            break;
        }
    }
}

char* execute_n_command(int n) {
    int last_command_index = n - 1;

    if (n <= 0 || n >= HISTLEN) {
        printf("Error: Invalid command number.\n");
        return NULL;
    }

    if(strcmp(history[last_command_index], "history\n") == 0 )
    {
        add_to_history(history[last_command_index]);
        print_history();
        return history[last_command_index];
    }

    if (history[last_command_index] != NULL && strcmp(history[last_command_index], "history\n") != 0 &&
        strcmp(history[last_command_index], "!!\n") != 0 &&
        (history[last_command_index][0] != '!' || !isdigit(history[last_command_index][1]))) {
        add_to_history(history[last_command_index]);
        return history[last_command_index];
    }


   

    printf("Error: No command found at position %d.\n", n);
    return NULL;
}



int main(int argc, char **argv) {
    char buffer[BUFFER_SIZE];
    cmdLine *cmd;
    int quit = 0;

    int debug_mode = -1;
    for(int i = 1; i < argc; i++)
    {
        if(argv[i][0] == '-' && argv[i][1] == 'd' && argv[i][2] == '\0')
        {
            debug_mode = 1;
        }


    }
    memset(history, 0, sizeof(char*) * HISTLEN);
    process *process_list = NULL;
    while (!quit) {
        displayPrompt();
        if(fgets(buffer, BUFFER_SIZE, stdin) == NULL){
            break;
        }
        


        if (strcmp(buffer, "!!\n") != 0 && (buffer[0] != '!' || !isdigit(buffer[1])))  
        {                     
            add_to_history(buffer);
        }

        cmd = parseCmdLines(buffer);
        
        if (strcmp(cmd->arguments[0], "!!") == 0) {
           char* toParse = execute_last_command();
           cmd = parseCmdLines(toParse);
        }

        else if (cmd->arguments[0][0] == '!' && isdigit(cmd->arguments[0][1])) {
            int index = 0;
            int i = 1;
            while (isdigit(cmd->arguments[0][i])) {
                index = index * 10 + (cmd->arguments[0][i] - '0');
                i++;
            }
            if (index > 0 && index < HISTLEN ) {
                char* toParse_n = execute_n_command(index);
                cmd = parseCmdLines(toParse_n);
            } else {
                printf("Invalid history index.\n");
            }
        
        } 
        

        else if (strcmp(cmd->arguments[0], "history") == 0) {
            print_history();
        }
   
         
        if (strcmp(cmd->arguments[0], "quit") == 0) {
            quit = 1;
            freeCmdLines(cmd);
            exit(EXIT_SUCCESS);
        }
        else if (strcmp(cmd->arguments[0], "procs") == 0) {
            
            printProcessList(&process_list);
        }

        
        else if (strcmp(cmd->arguments[0], "suspend") == 0) {
            char* pid = cmd->arguments[1];
            suspendCmd(pid, &process_list);
        }
        else if (strcmp(cmd->arguments[0], "wake") == 0) {
            char* pid = cmd->arguments[1];
            wakeCmd(pid, &process_list);
        }
        else if (strcmp(cmd->arguments[0], "kill") == 0) {
            char* pid = cmd->arguments[1];
            killCmd(pid, &process_list);
        } else {
            int pid = fork();
            if (pid == -1) {
                perror("Error forking");
            }
            else if (pid == 0) {
                if(debug_mode == 1)
                {
                    fprintf(stderr, "PID: %d\n", getpid());
                    fprintf(stderr, "Command: %s\n", cmd->arguments[0]);
                }
                execute(cmd, &process_list);
                exit(EXIT_SUCCESS);
            }
            else {
                addProcess(&process_list, cmd, pid);
                if(cmd->blocking || cmd->next)
                {               
                    waitpid(pid, NULL, 0);
                    updateProcessStatus(process_list, pid, TERMINATED);
                }
            }
        }
        
      
    }

    return 0;
}