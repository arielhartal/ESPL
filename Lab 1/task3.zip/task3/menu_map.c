#include <stdlib.h>
#include <stdio.h>
#include <string.h>
 
char* map(char *array, int array_length, char (*f) (char)){
  char* mapped_array = (char*)(malloc(array_length*sizeof(char)));
  for(int i = 0; i < array_length; i++)
  {
      mapped_array[i] = f(array[i]);
  }
  mapped_array[array_length] = '\0';  
  return mapped_array;
}
 

char my_get(char c)
{
    int ch = fgetc(stdin);
    if (ch == EOF) {
        return EOF;
    } else {
        return (char) ch;
    }
     
}

char cprt(char c)
{
    if(c >= 0x20 && c <= 0x7E)
    {
        printf("%c\n", c);
    }
    else
    {
        printf(".\n");
    }
    return c;
}

char encrypt(char c)
{
    if(c >= 0x20 && c <= 0x7E)
    {
        c+=1;
    }
    return c;
}

char decrypt(char c)
{
    if(c >= 0x20 && c <= 0x7E)
    {
        c-=1;
    }
    return c;
}


char xprt(char c)
{
    printf("%x\n", c);
    return c;
}


int task3a()
{
    while(1)
    {
        printf("Select operation from the following menu:\n");
        char input[100];
        if(fgets(input, 100, stdin) == NULL)
        {
            break;
        }
    }

    return 0;
}


struct fun_desc {
    char *name;
    char (*fun)(char);
};


struct fun_desc menu[] = {
    { "Get string ", my_get },
    { "Print string", cprt },
    { "Encrypt", encrypt},
    { "Decrypt", decrypt},
    { "Print Hex", xprt},
    { NULL, NULL } 
};

void display_menu(struct fun_desc menu[])
{
    int i = 0;
    while(menu[i].name != NULL)
    {
        printf("%d) %s\n", i ,menu[i].name);
        i++;
    }
}

int str_to_int(char* str) {
    int result = 0;
    int sign = 1;
    int i = 0;

    if (str[0] == '-') {
        sign = -1;
        i = 1;
    }

    for (; str[i] != '\0'; i++) {
        if (str[i] < '0' || str[i] > '9')
         {
            break;
        }
        result = result * 10 + (str[i] - '0');
    }

    return sign * result;
}

int task3b()
{
    char carray[5];
    for (int i = 0; i < 5; i++) {
        carray[i] = '\0';
    }
    char* carray_pointer = carray;

    char char_option[50];
    char* mapped_array = NULL;
    while(1)
    {
        printf("Please choose a function (ctrl^D for exit): \n");
        display_menu(menu);
        printf("Option: ");

        if(fgets(char_option, 50, stdin) == NULL)
        {
            printf("\n");
            break;
        }
        
        int option = str_to_int(char_option);

      


        if(option >= 0 && option < 5)
        {
            printf("Within bounds \n");
            mapped_array = map(carray_pointer, 5, menu[option].fun);
            carray_pointer = mapped_array;
            printf("%s\n", mapped_array);
            
            printf("DONE.\n"); 

        }
        else
        {
            printf("Not within bounds \n");
            break;
        }
        
    }
    if(mapped_array != NULL)
    {
        free(mapped_array);
    }
     
   return 0;
}

int main(int argc, char **argv){
   /* char arr1[] = {'H','E','Y','!'};
    char* arr2 = map(arr1, 4, xprt);
    printf("%s\n", arr2);
    free(arr2);*/

/*    int base_len = 5;
    char arr1[base_len];
    char* arr2 = map(arr1, base_len, my_get);
    char* arr3 = map(arr2, base_len, cprt);
    char* arr4 =     return 0;map(arr3, base_len, xprt);
    char* arr5 = map(arr4, base_len, encrypt);
    char* arr6 = map(arr5, base_len, decrypt);
    free(arr2);
    free(arr3);
    free(arr4);
    free(arr5);
    free(arr6);*/
    //task3a();
    task3b();
    return 0;  
}

