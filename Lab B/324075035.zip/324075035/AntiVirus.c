#include <stdio.h>
#include <stdlib.h>
#include <string.h>



char* infected_file;

typedef struct virus {
    unsigned short SigSize;
    char virusName[16];
    unsigned char* sig;
} virus;

/* Part 1a */
virus* readVirus(FILE* file) {
    virus* newVirus = malloc(sizeof(virus));

    if (fread(&newVirus->SigSize, sizeof(unsigned short), 1, file) != 1) 
    {
        free(newVirus);
        return NULL;
    }

    fread(newVirus->virusName, sizeof(char), 16, file);
    newVirus->sig = malloc(sizeof(unsigned char) * newVirus->SigSize);
    fread(newVirus->sig, sizeof(unsigned char), newVirus->SigSize, file);

    return newVirus;
    
}

void printVirus(virus* virus, FILE* output) {
    fprintf(output, "Virus name: %s\n", virus->virusName);
    fprintf(output, "Virus size: %d\n", virus->SigSize);

    fprintf(output, "Signature:\n");
    for (int i = 0; i < virus->SigSize; i++) {
        fprintf(output, "%02X ", virus->sig[i]);
    }
    fprintf(output, "\n\n");
}

/* Part 1b */

typedef struct link link;
struct link
{
    link *nextVirus;
    virus *vir;
};

void list_print(link* virus_list, FILE* output) {
    while (virus_list != NULL) {
        printVirus(virus_list->vir, output);
        virus_list = virus_list->nextVirus;
    }
}

link* list_append(link* virus_list, virus* data) {

    link* newLink = malloc(sizeof(link));
    newLink->vir = data;
    newLink->nextVirus = NULL;

    if (virus_list == NULL) {
        virus_list = newLink;
    } 

    else {
        link* current = virus_list;
        while (current->nextVirus != NULL) {
            current = current->nextVirus;
        }
        current->nextVirus = newLink;
    }

    return virus_list;
}


void list_free(link* virus_list) {
    while (virus_list != NULL) {
        link* temp = virus_list;
        virus_list = virus_list->nextVirus;
        free(temp->vir->sig);
        free(temp->vir);
        free(temp);
    }
}


struct fun_desc {
    char *name;
    link* (*fun)(link*);
};

link* load_signatures(link *virus_linked_list) {
    char file_name[256];
    printf("Enter file name: ");
    fgets(file_name, 256, stdin);
    file_name[strcspn(file_name, "\n")] = '\0'; // remove newline char
    
    FILE *file = fopen(file_name, "rb");
    if (file == NULL) {
        printf("Failed to open file %s\n", file_name);
        exit(0);
    }
    
     // check magic number
    char magic[5];
    magic[4] = '\0';
    fread(magic, sizeof(char), 4, file);
    if (strcmp(magic, "VISL") != 0) {
        printf("Error: invalid magic number.\n");
        exit(1);
    }

    virus *v;
    while ((v = readVirus(file)) != NULL) {
        virus_linked_list = list_append(virus_linked_list, v);
    }
    
    fclose(file);
    printf("Signatures loaded successfully.\n");
    return virus_linked_list;
}

link* print_signatures(link *virus_linked_list)
{
    list_print(virus_linked_list, stdout);
    return virus_linked_list;
}

link* quit (link* virus_link)
{
    list_free(virus_link);
    exit(1);
    
}





int str_to_int(char* str) {
    int result = 0;
    int sign = 1;
    int i = 0;

    if (str[0] == '-') {
        sign = -1;
        i = 1;
    }

    for (; str[i] != '\0'; i++) {
        if (str[i] < '0' || str[i] > '9')
         {
            break;
        }
        result = result * 10 + (str[i] - '0');
    }

    return sign * result;
}

void display_menu(struct fun_desc menu[])
{
    int i = 0;
    while(menu[i].name != NULL)
    {
        printf("%d) %s\n", i+1 ,menu[i].name);
        i++;
    }
}


/* Part 1c */

void detect_virus(char *buffer, unsigned int size, link *virus_list) {
    int i;
    link *curr_link;
    
    for (i = 0; i < size; i++) {
        curr_link = virus_list;
       
        while(curr_link != 0)
        {
            if (memcmp(curr_link->vir->sig, buffer+i, curr_link->vir->SigSize) == 0) {
                printf("Starting byte location: %d\n", i);
                printf("Virus name: %s\n", curr_link->vir->virusName);
                printf("Size of virus signature: %d\n", curr_link->vir->SigSize);
            }
            curr_link = curr_link->nextVirus;
        }
    }
}


link* detect_viruses(link* virus_link)
{
    FILE *file = fopen(infected_file, "rb");
    if (file == NULL) {
        printf("Failed to open file %s\n", infected_file);
        exit(0);
    }


    char *buffer = malloc(10000);
    int bytesRead = fread(buffer, sizeof(char), 10000, file);
    detect_virus(buffer, bytesRead, virus_link);
    free(buffer);
    fclose(file);
    return virus_link;
}


/* Part 2b */

void neutralize_virus(char *fileName, int signatureOffset) {
    printf("HERE\n");
    FILE *fp = fopen(fileName, "rb+");
    if (fp == NULL) {
        perror("Error opening file");
        return;
    }
    
    fseek(fp, signatureOffset, SEEK_SET);
    
    const char ret[] = {0xC3};
    fwrite(ret, sizeof(char), 1, fp);
    
    fclose(fp);
}

link* fix_file(link* virus_link)
{
   

    FILE *file = fopen(infected_file, "rb");
    if (file == NULL) {
        printf("Failed to open file %s\n", infected_file);
        exit(0);
    }

    char *buffer = malloc(10000);
    int bytesRead = fread(buffer, sizeof(char), 10000, file);
    int i;
    link *curr_link;
    for (i = 0; i < bytesRead; i++) {
        curr_link = virus_link;
       
        while(curr_link != 0)
        {
            if (memcmp(curr_link->vir->sig, buffer+i, curr_link->vir->SigSize) == 0) {
                neutralize_virus(infected_file, i);
                
            }
            curr_link = curr_link->nextVirus;
        }
    }
    
    
    free(buffer);
    fclose(file);
    return virus_link;
}

struct fun_desc menu[] = {
    { "Load Signatures ", load_signatures},
    { "Print Signatures", print_signatures },
    { "Detect viruses", detect_viruses},
    { "Fix file", fix_file},
    { "Quit", quit},
    { NULL, NULL } 
};


/*int task1a()
{

    
    FILE* sigFile = fopen(argv[1], "rb");
    if (sigFile == NULL) {
        printf("Error: could not open file '%s'.\n", argv[1]);
        exit(1);
    }

    char magic[5];
    magic[4] = '\0';
    fread(magic, sizeof(char), 4, sigFile);
    if (strcmp(magic, "VISL") != 0) {
        printf("Error: invalid magic number.\n");
        exit(1);
    }

    while (!feof(sigFile)) {
        virus* newVirus = readVirus(sigFile);
        if(newVirus != NULL)
        {
            printVirus(newVirus, stdout);
            free(newVirus->sig);
            free(newVirus);
        }
    }

    fclose(sigFile);
}*/

int main_loop(link* virus_list)
{
  
    char char_option[50];
    while(1)
    {
        printf("Please choose a function (ctrl^D for exit): \n");
        display_menu(menu);
        printf("Option: ");

        if(fgets(char_option, 50, stdin) == NULL)
        {
            printf("\n");
            break;
        }
        
        int option = str_to_int(char_option) - 1;

      


        if(option >= 0 && option < 5)
        {
            printf("Within bounds \n");

            virus_list = menu[option].fun(virus_list);
        }
        else
        {
            printf("Not within bounds \n");
            break;
        }
        
    }
     
   return 0;
}



int main(int argc, char** argv) {
  //  task1a();

    infected_file = argv[1];
    link* virus_list = NULL;
    main_loop(virus_list);

    return 0;
}
