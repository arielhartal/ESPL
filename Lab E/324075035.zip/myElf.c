#include <stdlib.h>
#include <stdio.h>
#include <elf.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <unistd.h>
#include <string.h>


typedef struct file_link file_link;	
struct file_link{
    void* map_start;
    char file_name[100];
    int file_size;
    file_link* next;
};


typedef struct {
 char debug_mode;
 char display_mode;
 char file_name[128];
 int unit_size;
 unsigned char mem_buf[10000];
 size_t mem_count;
 file_link* lst;
 /*
 .
 .
 Any additional fields you deem necessary
 */
} state;

struct fun_desc{
    void (*fun)(state*);
    char* name;
};

void Toggle_Debug_Mode(state* s){
    if(s->debug_mode)
    {
        s->debug_mode = 0;
        fprintf(stderr, "Debug flag off\n");
    } 
    else
    {
        s->debug_mode = 1;
        fprintf(stderr, "Debug flag on\n");
    }
}

void Examine_ELF_File(state* s){
    char buffer[100];
    printf("Please enter file name:\n");
    fgets(buffer, 100, stdin);
    buffer[strlen(buffer)-1] = '\0';

    struct stat sb;
    int fd = open(buffer, O_RDONLY);
    if(fd < 0){
        perror("open");
        exit(1);
    }

    if(fstat(fd, &sb) < 0){
        perror("fstat");
        close(fd);
        exit(1);
    }

    void* map_start = mmap(NULL, sb.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
    if(map_start == MAP_FAILED){
        perror("mmap");
        close(fd);
        exit(1);
    }

    Elf32_Ehdr* header = (Elf32_Ehdr*) map_start;
    if(header->e_ident[0] == ELFMAG0 && header->e_ident[1] == ELFMAG1 && header->e_ident[2] == ELFMAG2 && header->e_ident[3] == ELFMAG3){
        printf("Magic: %X %X %X %X\n", header->e_ident[0], header->e_ident[1], header->e_ident[2], header->e_ident[3]);
        if(header->e_ident[EI_DATA] == ELFDATA2LSB){
            printf("Data: 2's complement, little endian\n");
        } else {
            printf("Data: 2's complement, big endian\n");
        }
        printf("Entry Point: 0x%08X\n", header->e_entry);
        printf("Section Header Offset: %d\n", header->e_shoff);
        printf("Section Header Amount: %d\n", header->e_shnum);
        printf("Section Header Size: %d\n", header->e_shentsize);
        printf("Program Header Offset: %d\n", header->e_phoff);
        printf("Program Header Amount: %d\n", header->e_phnum);
        printf("Program Header Size: %d\n", header->e_phentsize);

        file_link* new_link = malloc(sizeof(file_link));
        strcpy(new_link->file_name, buffer);
        new_link->file_size = sb.st_size;
        new_link->map_start = map_start;
        new_link->next = s->lst;
        s->lst = new_link;
    } else {
        printf("file %s needs to be an ELF file\n", buffer);
    }
}

char* shdr_type(Elf32_Shdr shdr){
    if(shdr.sh_type == SHT_NULL) return "NULL";
    if(shdr.sh_type == SHT_PROGBITS) return "PROGBITS";
    if(shdr.sh_type == SHT_SYMTAB) return "SYMTAB";
    if(shdr.sh_type == SHT_STRTAB) return "STRTAB";
    if(shdr.sh_type == SHT_RELA) return "RELA";
    if(shdr.sh_type == SHT_HASH) return "HASH";
    if(shdr.sh_type == SHT_DYNAMIC) return "DYNAMIC";
    if(shdr.sh_type == SHT_NOTE) return "NOTE";
    if(shdr.sh_type == SHT_NOBITS) return "NOBITS";
    if(shdr.sh_type == SHT_REL) return "REL";
    if(shdr.sh_type == SHT_SHLIB) return "SHLIB";
    if(shdr.sh_type == SHT_DYNSYM) return "DYNSYM";
    if(shdr.sh_type == SHT_INIT_ARRAY) return "INIT_ARRAY";
    if(shdr.sh_type == SHT_FINI_ARRAY) return "FINI_ARRAY";
    if(shdr.sh_type == SHT_PREINIT_ARRAY) return "PREINIT_ARRAY";
    if(shdr.sh_type == SHT_GROUP) return "GROUP";
    if(shdr.sh_type == SHT_SYMTAB_SHNDX) return "SYMTAB_SHNDX";
    if(shdr.sh_type == SHT_NUM) return "NUM";
    if(shdr.sh_type == SHT_LOOS) return "LOOS";
    if(shdr.sh_type == SHT_GNU_ATTRIBUTES) return "GNU_ATTRIBUTES";
    if(shdr.sh_type == SHT_GNU_HASH) return "GNU_HASH";
    if(shdr.sh_type == SHT_GNU_LIBLIST) return "GNU_LIBLIST";
    if(shdr.sh_type == SHT_CHECKSUM) return "CHECKSUM";
    if(shdr.sh_type == SHT_LOSUNW) return "LOSUNW";
    if(shdr.sh_type == SHT_SUNW_move) return "SUNW_move";
    if(shdr.sh_type == SHT_SUNW_COMDAT) return "SUNW_COMDAT";
    if(shdr.sh_type == SHT_SUNW_syminfo) return "SUNW_syminfo";
    if(shdr.sh_type == SHT_GNU_verdef) return "GNU_verdef";
    if(shdr.sh_type == SHT_GNU_verneed) return "GNU_verneed";
    if(shdr.sh_type == SHT_GNU_versym) return "GNU_versym";
    if(shdr.sh_type == SHT_HISUNW) return "HISUNW";
    if(shdr.sh_type == SHT_HIOS) return "HIOS";
    if(shdr.sh_type == SHT_LOPROC) return "LOPROC";
    if(shdr.sh_type == SHT_HIPROC) return "HIPROC";
    if(shdr.sh_type == SHT_LOUSER) return "LOUSER";
    if(shdr.sh_type == SHT_HIUSER) return "HIUSER";
    return "";
}

void print_sections(state* s, void* map_start){
    Elf32_Ehdr* header = (Elf32_Ehdr*) map_start;
    Elf32_Shdr* shdr = (Elf32_Shdr*)(map_start + header->e_shoff);
    char* sections_names = (char*) (map_start + shdr[header->e_shstrndx].sh_offset);
    for(int i = 0; i < header->e_shnum; i++){
        printf("[%02d] %-20s %08x %05x %05d %s\n", 
        i, sections_names + shdr[i].sh_name, shdr[i].sh_addr, shdr[i].sh_offset, shdr[i].sh_size, shdr_type(shdr[i]));

        if(s->debug_mode){
            printf("Debug Information:\n");
            printf("  shstrndx: %d\n", header->e_shstrndx);
            printf("  section name offset: %d\n", shdr[i].sh_name);
        }
    }
}

void Print_Section_Names(state* s){
    file_link* temp = s->lst;
    while(temp != NULL){
        printf("%s's sections:\n", temp->file_name);
        print_sections(s, temp->map_start);
        printf("\n\n");
        temp = temp->next;
    }
}
void Print_Symbols_Helper(state* s, void* map_start){
    Elf32_Ehdr* header = (Elf32_Ehdr*) map_start;
    Elf32_Shdr* shdr = (Elf32_Shdr*)(map_start + header->e_shoff);
    char* sections_names = (char*) (map_start + shdr[header->e_shstrndx].sh_offset);
    for(int i = 0; i < header->e_shnum; i++){
        if(shdr[i].sh_type == SHT_SYMTAB || shdr[i].sh_type == SHT_DYNSYM){
            if(s->debug_mode){
                printf("Debug Information:\n");
                printf("  Size of symbol table '%s': %d\n", sections_names + shdr[i].sh_name ,shdr[i].sh_size);
                printf("  Number of symbols: %d\n", shdr[i].sh_size / shdr[i].sh_entsize);
            }

            printf("Symbol table '%s' contains %d entries:\n", sections_names + shdr[i].sh_name ,shdr[i].sh_size / shdr[i].sh_entsize);
            Elf32_Sym* symbols = (Elf32_Sym*)(map_start + shdr[i].sh_offset);
            char* symbols_names = (char*) (map_start + shdr[shdr[i].sh_link].sh_offset);
            for(int j = 0; j < shdr[i].sh_size / shdr[i].sh_entsize; j++){
                char* section_name;
                if(symbols[j].st_shndx == SHN_UNDEF){
                    section_name = "";
                    printf("[%02d] %08x UND %-20s %-20s\n", j, symbols[j].st_value,
                    section_name, symbols_names + symbols[j].st_name);
                }
                if(symbols[j].st_shndx == SHN_ABS){
                    section_name = "";
                    printf("[%02d] %08x ABS %-20s %-20s\n", j, symbols[j].st_value,
                    section_name, symbols_names + symbols[j].st_name);
                } else {
                    section_name =  sections_names + shdr[symbols[j].st_shndx].sh_name;
                    printf("[%02d] %08x %03d %-20s %-20s\n", j, symbols[j].st_value, symbols[j].st_shndx,
                    section_name, symbols_names + symbols[j].st_name);
                }
            }
        }
    }
}

void Print_Symbols(state* s){
    file_link* temp = s->lst;
    while(temp != NULL){
        printf("%s's sections:\n", temp->file_name);
        Print_Symbols_Helper(s, temp->map_start);
        printf("\n\n");
        temp = temp->next;
    }
}

int check_two_files(state* s){
    file_link* temp = s->lst;
    int counter = 0;
    while(temp != NULL){
        counter++;
        temp = temp->next;
    }
    return counter >= 2;
}

int only_one_symtab(void* map_start){
    Elf32_Ehdr* header = (Elf32_Ehdr*) map_start;
    Elf32_Shdr* shdr = (Elf32_Shdr*)(map_start + header->e_shoff);
    int counter = 0;
    for(int i = 0; i < header->e_shnum; i++){
        if(shdr[i].sh_type == SHT_SYMTAB || shdr[i].sh_type == SHT_DYNSYM){
            counter++;
        }
    }
    return counter == 1;
}

Elf32_Sym* get_sym_table(void* map_start, int* size, char** strtab){
    Elf32_Ehdr* header = (Elf32_Ehdr*) map_start;
    Elf32_Shdr* shdr = (Elf32_Shdr*)(map_start + header->e_shoff);
    for(int i = 0; i < header->e_shnum; i++){
        if(shdr[i].sh_type == SHT_SYMTAB || shdr[i].sh_type == SHT_DYNSYM){
            *strtab = (char*)(map_start + shdr[shdr[i].sh_link].sh_offset);
            *size = shdr[i].sh_size / shdr[i].sh_entsize;   
            return (Elf32_Sym*)(map_start + shdr[i].sh_offset);
        }
    }
    *size = 0;
    return NULL;
}

void check_undefined(Elf32_Sym* symtab, int symtab_size, char* strtab, char* sym_name){
    for(int i = 1; i < symtab_size; i++){
        if(strcmp(sym_name, strtab + symtab[i].st_name) == 0){
            if(symtab[i].st_shndx == SHN_UNDEF){
                fprintf(stderr, "symbol %s is undefined\n", sym_name);
                return;
            } else {
                return;
            }
        }
    }
    fprintf(stderr, "symbol %s is undefined\n", sym_name);
}

void check_defined(Elf32_Sym* symtab, int symtab_size, char* strtab, char* sym_name){
    if(strcmp(sym_name, "") == 0){//check if its a section
        return;
    }
    for(int i = 1; i < symtab_size; i++){
        if(strcmp(sym_name, strtab + symtab[i].st_name) == 0){
            if(symtab[i].st_shndx != SHN_UNDEF){
                fprintf(stderr, "symbol %s is multiply defined\n", sym_name);
                return;
            } else {
                return;
            }
        }
    }
}

void Check_Files_for_Merge(state* s){
    if(!check_two_files(s)){
        fprintf(stderr, "two files are needed to be checked\n");
        return;
    }
    if(!only_one_symtab(s->lst->map_start) || !only_one_symtab(s->lst->next->map_start)){
        fprintf(stderr, "only one symtab should be defined\n");
        return;
    }
    int symtab1_size,symtab2_size;
    char* strtab1, *strtab2;
    Elf32_Sym* symtab1 = get_sym_table(s->lst->map_start, &symtab1_size, &strtab1);
    Elf32_Sym* symtab2 = get_sym_table(s->lst->next->map_start, &symtab2_size, &strtab2);
    for(int i = 1; i < symtab1_size; i++){
        if(symtab1[i].st_shndx == SHN_UNDEF){
            check_undefined(symtab2, symtab2_size, strtab2, strtab1 + symtab1[i].st_name);
        } else {
            check_defined(symtab2, symtab2_size, strtab2, strtab1 + symtab1[i].st_name);
        }
    }
    for(int i = 1; i < symtab2_size; i++){
        if(symtab2[i].st_shndx == SHN_UNDEF){
            check_undefined(symtab1, symtab1_size, strtab1, strtab2 + symtab2[i].st_name);
        } else {
            check_defined(symtab1, symtab1_size, strtab1, strtab2 + symtab2[i].st_name);
        }
    }
}

Elf32_Shdr* get_section(Elf32_Shdr* shdr, int size, char* shstrtab, char* name){
    for (int i = 0; i < size; i++) {
        if(strcmp(name, shstrtab + shdr[i].sh_name) == 0){
            return shdr + i;
        }
    }
    return NULL;
}
int find_new_index(Elf32_Shdr* shdr, int size, char* shstrtab, char* name){
    for(int i = 0; i < size; i++){
        if(strcmp(shstrtab + shdr[i].sh_name, name) == 0){
            return i;
        }
    }
    return SHN_UNDEF;
}
void Merge_ELF_Files(state* s){
    if(!check_two_files(s)){
        fprintf(stderr, "two files are needed to be checked\n");
        return;
    }
    if(!only_one_symtab(s->lst->map_start) || !only_one_symtab(s->lst->next->map_start)){
        fprintf(stderr, "only one symtab should be defined\n");
        return;
    }
    FILE* file = fopen("out.ro", "wb");
    void* map_start1 = s->lst->next->map_start;
    void* map_start2 = s->lst->map_start;
    Elf32_Ehdr* header1 =(Elf32_Ehdr*)map_start1;
    Elf32_Ehdr* header2 =(Elf32_Ehdr*)map_start2;
    Elf32_Shdr* shdr2 = (Elf32_Shdr*)(map_start2 + header2->e_shoff);
    Elf32_Shdr* shdr1 = (Elf32_Shdr*)(map_start1 + header1->e_shoff);
    char* second_shstrtab = (char*)(map_start2 + shdr2[header2->e_shstrndx].sh_offset);
    int nwrite = fwrite((char*)map_start1, 1, 54, file);
    printf("Written %d to file\n", nwrite);
    char new_shdr[header1->e_shnum * header1->e_shentsize];
    memcpy(new_shdr, (char*)(shdr1), header1->e_shnum * header1->e_shentsize);
    char* shstrtab = (char*)(map_start1 + shdr1[header1->e_shstrndx].sh_offset);
    for(int i = 0; i < header1->e_shnum; i++){
        printf("name = %s\n", shstrtab + shdr1[i].sh_name);
        int offset = ftell(file);
        printf("offset = %x\n", offset);
        if(strncmp(shstrtab + shdr1[i].sh_name, ".text", 5) == 0){
            Elf32_Shdr* section = get_section(shdr2, header2->e_shnum, second_shstrtab, ".text");
            nwrite = fwrite((char*)(map_start1 + shdr1[i].sh_offset), 1, shdr1[i].sh_size, file);
            printf(".text: Written %d to file\n", nwrite);
            if(section != NULL){
                nwrite = fwrite((char*)(map_start2 + section->sh_offset), 1, section->sh_size, file);
                printf(".text: Written %d to file\n", nwrite);
                printf("Size = %x + %x\n", ((Elf32_Shdr*)new_shdr)[i].sh_size, section->sh_size);
                ((Elf32_Shdr*)new_shdr)[i].sh_size += section->sh_size;
                ((Elf32_Shdr*)new_shdr)[i].sh_offset = offset;
            } 
        } else if(strcmp(shstrtab + shdr1[i].sh_name, ".data") == 0){
            Elf32_Shdr* section = get_section(shdr2, header2->e_shnum, second_shstrtab, ".text");
            nwrite = fwrite((char*)(map_start1 + shdr1[i].sh_offset), 1, shdr1[i].sh_size, file);
            printf(".data: Written %d to file\n", nwrite);
            if(section != NULL){
                nwrite = fwrite((char*)(map_start2 + section->sh_offset), 1, section->sh_size, file);
                printf(".data: Written %d to file\n", nwrite);
                printf("Size = %x + %x\n", ((Elf32_Shdr*)new_shdr)[i].sh_size, section->sh_size);
                ((Elf32_Shdr*)new_shdr)[i].sh_size += section->sh_size;
                ((Elf32_Shdr*)new_shdr)[i].sh_offset = offset;
            } 

        } else if(strcmp(shstrtab + shdr1[i].sh_name, ".rodata") == 0){
            Elf32_Shdr* section = get_section(shdr2, header2->e_shnum, second_shstrtab, ".text");
            nwrite = fwrite((char*)(map_start1 + shdr1[i].sh_offset), 1, shdr1[i].sh_size, file);
            printf(".rodata: Written %d to file\n", nwrite);
            if(section != NULL){
                nwrite = fwrite((char*)(map_start2 + section->sh_offset), 1, section->sh_size, file);
                printf(".rodata: Written %d to file\n", nwrite);
                printf("Size = %x + %x\n", ((Elf32_Shdr*)new_shdr)[i].sh_size, section->sh_size);
                ((Elf32_Shdr*)new_shdr)[i].sh_size += section->sh_size;
                ((Elf32_Shdr*)new_shdr)[i].sh_offset = offset;
            } 
        } else if(strcmp(shstrtab + shdr1[i].sh_name, ".shstrtab") == 0){
            nwrite = fwrite((char*)(map_start1 + shdr1[i].sh_offset), 1, shdr1[i].sh_size, file);
            ((Elf32_Shdr*)new_shdr)[i].sh_offset = offset;
            printf(".rodata: Written %d to file\n", nwrite);
        } else if(strcmp(shstrtab + shdr1[i].sh_name, ".symtab") == 0){
            char symbols[shdr1[i].sh_size];
            memcpy(symbols, (char*)(map_start1 + shdr1[i].sh_offset), shdr1[i].sh_size);
            int symtab1_size,symtab2_size;
            char* strtab1, *strtab2;
            Elf32_Sym* symtab1 = get_sym_table(s->lst->next->map_start, &symtab1_size, &strtab1);
            Elf32_Sym* symtab2 = get_sym_table(s->lst->map_start, &symtab2_size, &strtab2);
            for(int i = 1; i < symtab1_size; i++){
                if(symtab1[i].st_shndx == SHN_UNDEF){
                    for(int j = 1; j < symtab2_size; j++){
                        if(strcmp(strtab1 + symtab1[i].st_name, strtab2 + symtab2[j].st_name) == 0){
                            printf("i = %d, j = %d\n", i, j);
                            char* name = second_shstrtab + shdr2[(symtab2+j)->st_shndx].sh_name;
                            ((Elf32_Sym*)symbols + i)->st_shndx = find_new_index(shdr1, symtab1_size, shstrtab, name);
                            ((Elf32_Sym*)symbols + i)->st_value = (symtab2+j)->st_value;
                        }
                    }
                }
            }
            nwrite = fwrite(symbols, 1, shdr1[i].sh_size, file);
            ((Elf32_Shdr*)new_shdr)[i].sh_offset = offset;
            printf(".rodata: Written %d to file\n", nwrite);
        } else {
            nwrite = fwrite((char*)(map_start1 + shdr1[i].sh_offset), 1, shdr1[i].sh_size, file);
            printf("else: Written %d to file\n", nwrite);
            if(i != 0)
                ((Elf32_Shdr*)new_shdr)[i].sh_offset = offset;
        }
    }
    
    int shoff = ftell(file);
    nwrite = fwrite((char*)new_shdr, 1, header1->e_shnum * header1->e_shentsize, file);
    printf("sections: Written %d to file\n", nwrite);
    printf("shoff = %d\n", shoff);
    fseek(file, 32, SEEK_SET);
    nwrite = fwrite((char*)&shoff, 4, 1, file);
    printf("shoff: Written %d to file\n", nwrite);
    fclose(file);
}

void Quit(state* s){
    free(s);
    fprintf(stderr, "quiting...\n");
    exit(0);
}



int main(int argc, char** argv){
    state* s = malloc(sizeof(state));
    s->debug_mode = 0;
    s->unit_size = 1;
    s->lst = NULL;
    strcpy(s->file_name, "");
    struct fun_desc menu[] = {
    {Toggle_Debug_Mode, "Toggle Debug Mode"},
    {Examine_ELF_File, "Examine ELF File"},
    {Print_Section_Names, "Print Section Names"},
    {Print_Symbols, "Print Symbols"},
    {Check_Files_for_Merge, "Check Files for Merge"},
    {Merge_ELF_Files, "Merge ELF Files"},
    {Quit, "Quit"}, 
    { NULL, NULL } };
    int menuSize = sizeof(menu) / sizeof(struct fun_desc) - 1;
    char input[100];
    while(1){
        printf("Select operation from the following menu:\n");
        for(int i = 0; i < menuSize; i++){
            printf("%d-%s\n", i, menu[i].name);
        }
        printf("option: ");
        if(fgets(input, 100, stdin) == NULL){
            break;
        }
        int option;
        sscanf(input, "%d\n", &option);
        if(option < 0 || option >= menuSize){
            printf("Not within bounds\n");
            break;
        }
        printf("Within bounds\n");
        menu[option].fun(s);
        printf("DONE.\n\n");
    } 
}