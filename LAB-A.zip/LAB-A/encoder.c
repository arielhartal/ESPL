#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    /*Part 1*/

    int debug_mode = -1;
    for(int i = 1; i < argc; i++)
    {
        if(argv[i][0] == '+' && argv[i][1] == 'D' && argv[i][2] == '\0')
        {
            debug_mode = 1;
        }

        else if(argv[i][0] == '-' && argv[i][1] == 'D' && argv[i][2] == '\0')
        {
            debug_mode = 0;
        }

        if(debug_mode == 1 && argv[i][0] != '+' && argv[i][1] != 'D')
        {
            fprintf(stderr, "%s\n", argv[i]);
            
        }



    }

    /*Part 2*/
    if(debug_mode == -1)
    {
        int direction = 0, c;
        FILE *infile = stdin, *outfile = stdout;
        int encode = 0;
        char* encode_value;
        for (int i = 1; i < argc; i++) {
            if (argv[i][0] == '-') {
                if (argv[i][1] == 'i') 
                {
                    infile = fopen(argv[i]+2, "r");
                    if (!infile) 
                    {
                        fprintf(stderr, "Unable to open input file '%s'\n", argv[i]+2);
                        exit(1);
                    }
                } else if (argv[i][1] == 'o') 
                {
                    outfile = fopen(argv[i]+2, "w");
                    if (!outfile) 
                    {
                        fprintf(stderr, "Unable to open output file '%s'\n", argv[i]+2);
                        exit(1);
                    }
                } else if(argv[i][1] == 'e')
                {
                    direction = -1;
                    encode = 1;
                    encode_value = argv[i] + 2;
                }
            }
            if (argv[i][0] == '+')
            {
                if(argv[i][1] == 'e')
                {
                    direction = 1;
                    encode = 1;
                    encode_value = argv[i] + 2;
                }
            }
    
        }
        if(encode)
        {
            char *check_encode_value = encode_value;
            while (*check_encode_value) 
            {
                if (*check_encode_value < '0' || *check_encode_value > '9')
                {
                    fprintf(stderr, "Invalid argument: %s\n", argv[1]);
                    exit(1);
                }
                check_encode_value++;
            }
        
            int i = 0;
            while ((c = fgetc(infile)) != EOF) 
            {
                int encoded_char = c;
                
            if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9'))
                {
                    if(direction != 0)
                    {
                        int shift = encode_value[i] - '0';
                        
                        if (direction == -1) 
                        {
                            shift = -shift;
                        }
                        if (c >= 'A' && c <= 'Z') 
                        {
                            encoded_char = ((c - 'A') + shift + 26) % 26 + 'A';
                        } else if (c >= 'a' && c <= 'z') 
                        {
                            encoded_char = ((c - 'a') + shift + 26) % 26 + 'a';
                        } else if (c >= '0' && c <= '9') 
                        {
                            encoded_char = ((c - '0') + shift + 10) % 10 + '0';
                        }

                    }
                }
                fputc(encoded_char, outfile);
                i++;
                if(encode_value[i] == '\0')
                {
                    i = 0;
                }
            }

            fclose(infile);
            fclose(outfile);
        }
    }
    return 0;
}
